<template>
  <div>
    <h1>Main Page</h1>
    <div class="ref-login">
      <a href="http://localhost:8081/#/login">Click to Login</a>
    </div>
    <div class="ref-login">
      <a href="http://localhost:8081/#/orderlist">Click to look order list</a>
    </div>
  </div>
</template>

<script></script>

<style scoped></style>
