<template>
  <div>
    <h1 class="app-title">MetaHome</h1>
    <form class="signin-form">
      <h1 class="login-cap">Login</h1>
      <label for="id-input">User ID</label>
      <div class="id-input">
        <input type="number" class="userId" placeholder="300321101" />
      </div>
      <label for="password-input">Password</label>
      <div class="password-input">
        <input type="password" class="userPassword" placeholder="Password" />
      </div>
      <button class="login-button" type="submit">Login</button>
    </form>

    <button type="button" id="google-btn" data-type="google">
      <img
        class="google-icon"
        src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg"
      />Login with google
    </button>
    <p class="text-center">
      Do have have an account?
      <a href="/signup">Sign up</a>
    </p>
  </div>
</template>

<script>
import LoginService from "../service/LoginService.js";

export default {
  name: "userLogin",
  data() {
    return {
      userLoginRequest: { usertId: "", password: "" },
      message: "",
    };
  },
  methods: {
    login() {
      LoginService.login(this.userLoginRequest)
        .then((response) => {
          var user = response.data;
          console.log(user);
        })
        .catch((e) => {
          this.userLoginRequest.userId = "";
          this.userLoginRequest.password = "";
          console.log("cannot get request");
          this.message = e.response.data.message;
        });
    },
  },
  mounted() {
    this.message = "";
  },
};
</script>

<style scoped>
.app-title {
  color: blueviolet;
  font-size: 30px;
}

.signin-form {
  width: 100%;
  max-width: 480px;
  padding: 100px;
  margin: auto;
  margin-top: 5rem;
}

.google-icon {
  margin-right: 10px;
  width: 18px;
  height: 18px;
}

#google-btn:hover {
  background: #013f7c;
}
</style>
