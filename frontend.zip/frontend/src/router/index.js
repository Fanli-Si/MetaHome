import { createWebHashHistory, createRouter } from "vue-router";
import UserLogin from "../components/UserLogin";
import OrderList from "../components/OrderList";
import MainPage from "../components/MainPage";

const routes = [
  {
    path: "/",
    name: "MainPage",
    component: MainPage,
  },
  {
    path: "/orderlist",
    name: "OrderList",
    component: OrderList,
  },
  {
    path: "/login",
    name: "UserLogin",
    component: UserLogin,
  },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
