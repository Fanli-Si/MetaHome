<template>
  <div>
    <h1>Order List</h1>
    <ul v-for="order in orders" :key="order.id">
      <li>({{ order.order_number }}): {{ order.item_title }}</li>
    </ul>
  </div>
</template>

<script>
import http from "../http-common.js";

export default {
  data() {
    return {
      orders: [],
    };
  },
  methods: {},
  mounted() {
    http
      .get("/order")
      .then((response) => {
        this.orders = response.data;
        console.log(this.orders);
      })
      .catch((e) => {
        console.log("not able to get data");
        console.log(e.response.data);
      });
  },
};
</script>

<style scoped></style>
