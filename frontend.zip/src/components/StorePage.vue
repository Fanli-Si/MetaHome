<template>
  <div>
    <h1>MetaHome Storefront</h1>
    <label>Total Cost:</label><p id="total"></p>
  
    <label for="checkoutList">Items in Cart:</label>
    <div class="checkoutList" id="checkoutList"></div>
    <a href="http://localhost:8081/#/checkout">
      <button class="checkoutBtn">Checkout</button>
    </a>
    <button v-on:click="clearCheckout()">Clear Cart</button>
    <section>
        <div>
            <ul v-for="item in items" :key="item.itemId">
            <li class="itemName">{{ item.itemName }}<br/>
                ${{ item.cost }}<br/>
                ({{ item.department }})</li><br/>
                <button v-on:click="addToList(item.itemName, item.cost)">Add to Cart</button>
            </ul>
        </div>
    </section>
  </div>
</template>

<script>

var itemList="";
let totalCost=0;

import http from "../http-common.js";

export default {
  data() {
    return {
      items: [],
    };
  },
  methods: {
    addToList: function(item,cost){
      totalCost+= cost;
      itemList+=item +",";
      document.getElementById("checkoutList").innerHTML =  itemList;
      document.getElementById("total").innerHTML = "$"+totalCost;
      console.log(itemList);
  },
    clearCheckout :function(){
      itemList = "";
      totalCost=0;
      document.getElementById("checkoutList").innerHTML="";
      document.getElementById("total").innerHTML="";
    }
  },
  mounted() {
    http
      .get("/items")
      .then((response) => {
        this.items = response.data;
        console.log(this.items);
      })
      .catch((e) => {
        console.log("not able to get data");
        console.log(e.response.data);
      });
  },

};
</script>

<style scoped>

h1{
    margin-bottom: 20px;
    text-decoration-line: underline;
}
li {
    display: inline-block;
}
ul {
    white-space: nowrap;
    float: left;
    width: 19%;
    padding: 45px;
    border: 2px solid black;
    text-align: center;
    background-color: coral;
    margin-right: 5px;
}

label{
  font-weight: bold;
}

Button:hover{
  color:aqua;
}
.checkoutBtn{

  margin-bottom: 15px;
}



.itemName{
  font-weight: bold;
}

.checkoutList{
  width: 400px;
  height: 100px;
  overflow: auto;
  text-align: center;
  margin: auto;
}



</style>
