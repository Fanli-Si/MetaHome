<template>
  <div class = "background">
    <h1>Checkout</h1>
    <section>
        <div>
            <ul v-for="item in items" :key="item.itemId">
            <li>{{ item.itemName }}<br/>
                ({{ item.department }})</li>
            </ul>
        </div>
    </section>
  </div>
</template>

<script>
import http from "../http-common.js";

export default {
  data() {
    return {
      items: [],
    };
  },
  methods: {},
  mounted() {
    http
      .get("/items")
      .then((response) => {
        this.items = response.data;
        console.log(this.items);
      })
      .catch((e) => {
        console.log("not able to get data");
        console.log(e.response.data);
      });
  },
};
</script>

<style scoped>


h1{
    margin-bottom: 20px;
}
li {
    display: inline-block;
}
ul {
    white-space: nowrap;
    float: left;
    width: 25%;
    padding: 45px;
    border: 2px solid black;
    text-align: center;
}

</style>
