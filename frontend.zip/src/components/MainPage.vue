<template>
  <div>
    <h1>Main Page</h1>

  </div>
</template>

<script></script>

<style scoped></style>
