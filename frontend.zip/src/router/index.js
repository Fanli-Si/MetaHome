import { createWebHashHistory, createRouter } from "vue-router";
import UserLogin from "../components/UserLogin";
import OrderList from "../components/OrderList";
import StorePage from "../components/StorePage";
import CheckoutPage from "../components/CheckoutPage";

const routes = [
  {
    path: "/",
    name: "StorePage",
    component: StorePage,
  },
  {
    path: "/orderlist",
    name: "OrderList",
    component: OrderList,
  },
  {
    path: "/login",
    name: "UserLogin",
    component: UserLogin,
  },
  {
    path: "/checkout",
    name:"CheckoutPage",
    component:CheckoutPage,
  }

];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
