import http from "../http-common.js";

class OrderService {
  order(data) {
    return http.post("/order", data);
  }
}

export default new OrderService();
